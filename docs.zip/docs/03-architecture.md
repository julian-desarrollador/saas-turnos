# 03 · Arquitectura

**Estado:** borrador · **Owner:** Arquitectura · **Última actualización:** 2026-07-27

## Propósito

Describir la arquitectura del sistema: sus componentes, cómo se comunican, dónde vive cada responsabilidad y qué reglas estructurales no se negocian.

## Índice

1. [Vista general del sistema](#1-vista-general-del-sistema)
2. [Capas y responsabilidades](#2-capas-y-responsabilidades)
3. [Modelo de aplicaciones y rutas](#3-modelo-de-aplicaciones-y-rutas)
4. [Flujo de una request](#4-flujo-de-una-request)
5. [Server Actions vs Route Handlers](#5-server-actions-vs-route-handlers)
6. [Trabajo asincrónico](#6-trabajo-asincrónico)
7. [Idempotencia](#7-idempotencia)
8. [Caché y estado](#8-caché-y-estado)
9. [Almacenamiento de archivos](#9-almacenamiento-de-archivos)
10. [Integraciones externas](#10-integraciones-externas)
11. [Incorporación progresiva de servicios](#11-incorporación-progresiva-de-servicios)
12. [Objetivos de performance](#12-objetivos-de-performance)
13. [Observabilidad](#13-observabilidad)
14. [Restricciones arquitectónicas](#14-restricciones-arquitectónicas)

## 1. Vista general del sistema

Diagrama y descripción de los bloques: aplicación Next.js en Vercel, PostgreSQL, Redis, Trigger.dev, R2 y proveedores externos.

## 2. Capas y responsabilidades

Separación entre UI, casos de uso y acceso a datos. Regla base: la UI no consulta la base de datos directamente.

La separación se aplica con criterio proporcional. La mayor parte del producto es gestión de datos y no justifica una capa de dominio pura; el motor de reservas sí, porque concentra reglas complejas que deben poder probarse sin base de datos ni framework.

## 3. Modelo de aplicaciones y rutas

Superficies del producto: panel del negocio (autenticado), página pública de reserva, back-office de plataforma (`18-platform-admin.md`) y endpoints de integración.

## 4. Flujo de una request

Recorrido desde el navegador: middleware, resolución de sesión y tenant, autorización, caso de uso dentro de una transacción con contexto de tenant, base de datos y respuesta.

## 5. Server Actions vs Route Handlers

Criterio de uso: Server Actions para mutaciones originadas en la UI propia; Route Handlers para webhooks, integraciones y consumo externo.

## 6. Trabajo asincrónico

Qué se ejecuta fuera del request: recordatorios, reintentos de envío, conciliación de pagos, reconciliación de membresías y procesos por lote.

Patrón general: el trabajo pendiente se persiste como estado en la base y una tarea recurrente lo despacha. No se programan tareas individuales por cada entidad de negocio, porque el volumen de tareas pasaría a crecer con el volumen de turnos (ADR-009).

## 7. Idempotencia

Dueño único del patrón. Toda operación disparada por un evento externo o reintentable —webhooks de identidad, pagos y mensajería, y todo envío de notificación— usa el mismo mecanismo de clave de idempotencia y marcado transaccional. Los documentos de cada integración lo referencian en lugar de definir el suyo.

## 8. Caché y estado

Niveles disponibles y cuándo corresponde cada uno. Regla de orden: la caché se introduce cuando hay una medición que la justifica, no por anticipado, porque en un sistema multi-tenant cada nivel de caché es una vía potencial de contaminación entre negocios. Convención de claves por tenant en `06-multi-tenant.md` §9.

## 9. Almacenamiento de archivos

Uso de Cloudflare R2 para logos y adjuntos: organización de rutas por tenant, subida y acceso mediante URLs firmadas.

## 10. Integraciones externas

Patrón común: contrato interno propio, una implementación por proveedor, manejo de errores, webhooks firmados y trazabilidad. Ningún módulo de dominio conoce al proveedor, lo que hace reversible cualquier cambio de vendor.

## 11. Incorporación progresiva de servicios

Cada servicio externo entra cuando hay una necesidad demostrada, con su criterio de activación explícito. Redis no es necesario como caché al inicio: su primer uso real es el rate limiting de la superficie pública. Trigger.dev entra con los recordatorios. Documentar esto evita pagar y operar cuatro proveedores antes de tener clientes.

## 12. Objetivos de performance

Objetivos numéricos que hacen verificable la palabra "escalable": latencia objetivo de la vista de agenda, del cálculo de disponibilidad y de la confirmación de un turno, medidas en percentil 95 y con el volumen de datos esperado a tres años.

Estos números son los que monitorea `12-deployment.md` §9 y los que sirven como criterio de salida de la fase de escala.

## 13. Observabilidad

Logs estructurados, correlación por request y por tenant, métricas y alertas mínimas para operar.

## 14. Restricciones arquitectónicas

Decisiones que no se rompen sin un ADR: aislamiento por tenant en toda consulta, sin lógica de negocio en componentes, sin acceso directo a Prisma desde la UI, y ninguna dependencia de un proveedor externo dentro del dominio.
