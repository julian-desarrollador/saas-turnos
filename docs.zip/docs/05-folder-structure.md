# 05 · Estructura de carpetas

**Estado:** borrador · **Owner:** Arquitectura · **Última actualización:** 2026-07-27

## Propósito

Establecer dónde va cada archivo y por qué, de modo que cualquier desarrollador ubique código nuevo sin preguntar y el proyecto no degrade con el tiempo.

## Índice

1. [Principios de organización](#1-principios-de-organización)
2. [Árbol de nivel raíz](#2-árbol-de-nivel-raíz)
3. [Rutas de la aplicación](#3-rutas-de-la-aplicación)
4. [Módulos de dominio](#4-módulos-de-dominio)
5. [Código compartido](#5-código-compartido)
6. [Componentes de UI](#6-componentes-de-ui)
7. [Configuración e infraestructura](#7-configuración-e-infraestructura)
8. [Tests](#8-tests)
9. [Convenciones de nombres](#9-convenciones-de-nombres)
10. [Reglas de dependencia entre capas](#10-reglas-de-dependencia-entre-capas)

## 1. Principios de organización

Organización por módulo de dominio antes que por tipo de archivo; colocación cercana de lo que cambia junto; límites explícitos entre módulos.

## 2. Árbol de nivel raíz

Carpetas de primer nivel del repositorio y qué contiene cada una.

## 3. Rutas de la aplicación

Agrupación de rutas por superficie: panel del negocio, reserva pública, back-office y API. Uso de layouts y grupos de rutas.

## 4. Módulos de dominio

Estructura interna de cada módulo (agenda, clientes, empleados, servicios, configuración, notificaciones): casos de uso, esquemas de validación, repositorio y componentes propios. El motor de reservas es el único que además aísla una capa de dominio pura, por el motivo explicado en `03-architecture.md` §2.

## 5. Código compartido

Qué vive en la capa común: utilidades, tipos, errores, cliente de base de datos, helpers de autorización y wrappers de proveedores.

## 6. Componentes de UI

Separación entre primitivas de shadcn/ui, componentes compartidos del producto y componentes específicos de un módulo.

## 7. Configuración e infraestructura

Ubicación de configuración de entorno, definiciones de jobs, migraciones y scripts operativos.

## 8. Tests

Dónde viven los archivos de prueba y cómo se nombran según su tipo. La estrategia —qué se testea y con qué exigencia— es competencia de `17-testing.md`.

## 9. Convenciones de nombres

Convenciones para archivos, carpetas, componentes, funciones, tipos y variables.

## 10. Reglas de dependencia entre capas

Qué capa puede importar a qué otra, y cómo se verifica automáticamente para que la regla no dependa de la memoria del equipo.
