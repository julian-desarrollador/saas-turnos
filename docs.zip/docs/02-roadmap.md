# 02 · Roadmap

**Estado:** borrador · **Owner:** Producto + Arquitectura · **Última actualización:** 2026-07-27

## Propósito

Ordenar la construcción del producto en fases con alcance cerrado y criterios de salida medibles, para evitar construir features avanzadas sobre bases incompletas.

## Índice

1. [Principios de priorización](#1-principios-de-priorización)
2. [Fase 0 · Decisiones y fundaciones](#2-fase-0--decisiones-y-fundaciones)
3. [Fase 1 · MVP y modelo comercial](#3-fase-1--mvp-y-modelo-comercial)
4. [Fase 2 · Recordatorios y reserva online](#4-fase-2--recordatorios-y-reserva-online)
5. [Fase 3 · Cobro](#5-fase-3--cobro)
6. [Fase 4 · Escala y multi-sucursal](#6-fase-4--escala-y-multi-sucursal)
7. [Backlog no priorizado](#7-backlog-no-priorizado)
8. [Riesgos y dependencias](#8-riesgos-y-dependencias)

## 1. Principios de priorización

Reglas para decidir qué entra en cada fase: primero lo que valida el modelo multi-tenant, después lo que genera valor visible al negocio, al final lo que optimiza. Ninguna fase arranca con decisiones estructurales abiertas.

## 2. Fase 0 · Decisiones y fundaciones

**Primer entregable: cerrar los ADR de `15-decisions.md`.** No es trabajo previo al proyecto, es la primera tarea con responsable y fecha. Cuatro de esas decisiones —aislamiento, identificación del tenant, sucursales y almacenamiento temporal de los turnos— definen el esquema de la base, y tomarlas por omisión durante la implementación cuesta una migración años después.

Luego: repositorio, entornos, esquema base, autenticación, resolución de tenant, layout y sistema de diseño.

Criterio de salida: los ADR están en estado aceptado y un negocio de prueba puede crear usuarios aislados, verificado por las pruebas de aislamiento de `17-testing.md` §4.

## 3. Fase 1 · MVP y modelo comercial

Agenda operativa, servicios, empleados, clientes, horarios y turnos creados internamente.

Incluye, además, el modelo comercial: planes, límites y margen unitario documentados en `11-payments.md` §2. Se define acá y no en la fase de cobro, porque la funcionalidad más cara del producto se entrega en la Fase 2 y no puede regalarse sin conocer su costo.

Criterio de salida: un negocio real reemplaza su planilla, y existe una tabla de márgenes por plan con supuestos de volumen.

## 4. Fase 2 · Recordatorios y reserva online

Página pública de reserva, tarea de barrido en Trigger.dev, recordatorios por WhatsApp y rate limiting de la superficie pública.

Criterio de salida: recordatorios enviados en producción con métricas de entrega, y los controles de `13-security.md` §7 implementados y probados.

## 5. Fase 3 · Cobro

Implementación de la suscripción con Mercado Pago, aplicación de los límites por plan, conciliación y gestión de morosidad, sobre el modelo comercial ya definido en la Fase 1.

Criterio de salida: cobro recurrente funcionando, conciliación automática y suspensión por impago probada de punta a punta.

## 6. Fase 4 · Escala y multi-sucursal

Interfaz de sucursales sobre el esquema que ya las contempla (ADR-004), reportes, optimizaciones de consulta, caché y archivado de históricos.

Criterio de salida: los objetivos de latencia de `03-architecture.md` §12 se sostienen con el volumen de datos proyectado a tres años.

## 7. Backlog no priorizado

Ideas registradas sin compromiso de fecha, con nota de por qué están postergadas.

## 8. Riesgos y dependencias

Dependencias externas que pueden mover fechas: aprobación de plantillas de WhatsApp, verificación de la cuenta de negocio, definición del proveedor de mensajería (ADR-007) y revisión legal de `16-compliance.md` antes de operar con verticales de salud.
