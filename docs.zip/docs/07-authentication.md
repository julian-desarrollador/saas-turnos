# 07 · Autenticación y autorización

**Estado:** borrador · **Owner:** Arquitectura · **Última actualización:** 2026-07-27

## Propósito

Definir cómo se identifican los usuarios, cómo se relacionan con los negocios y qué puede hacer cada rol. Distingue autenticación (quién sos) de autorización (qué podés hacer), y establece que cada una tiene una fuente de verdad distinta.

## Índice

1. [Modelo de identidad](#1-modelo-de-identidad)
2. [Rol de Clerk y límites](#2-rol-de-clerk-y-límites)
3. [Flujos de acceso](#3-flujos-de-acceso)
4. [Invitaciones y alta de empleados](#4-invitaciones-y-alta-de-empleados)
5. [Roles](#5-roles)
6. [Matriz de permisos](#6-matriz-de-permisos)
7. [Autorización en el servidor](#7-autorización-en-el-servidor)
8. [Protección de rutas](#8-protección-de-rutas)
9. [Acceso público sin sesión](#9-acceso-público-sin-sesión)
10. [Sincronización y reconciliación](#10-sincronización-y-reconciliación)
11. [Acceso interno del equipo](#11-acceso-interno-del-equipo)

## 1. Modelo de identidad

Relación entre el usuario de Clerk, la membresía en un negocio y el registro de empleado en nuestra base. La identidad la provee Clerk; la membresía y el rol son datos nuestros.

## 2. Rol de Clerk y límites

Clerk responde una única pregunta: quién es el usuario. Las membresías y los roles se almacenan y consultan en nuestra base de datos, y son la única fuente al autorizar (ADR-001).

Esta sección documenta también las consecuencias operativas de esa frontera: qué se replica desde Clerk, qué pasa durante una caída del proveedor y cómo se controla su costo, que crece por organización activa.

## 3. Flujos de acceso

Registro, inicio de sesión, recuperación de cuenta, selección de negocio activo y cambio entre negocios.

## 4. Invitaciones y alta de empleados

Flujo de invitación por email, aceptación, asignación de rol y vinculación con la ficha del profesional. El envío del correo es responsabilidad de la capa de notificaciones (`10-notifications.md` §8), no de una integración aparte.

## 5. Roles

Roles previstos: Owner, Admin, Profesional y Recepción. Alcance y limitaciones de cada uno.

## 6. Matriz de permisos

Tabla de permisos por recurso y acción (agenda, clientes, empleados, servicios, configuración, facturación, reportes) cruzada con los roles.

Decisión abierta: si el modelo se mantiene en roles fijos o evoluciona a permisos granulares por recurso. Está registrada como pendiente en `15-decisions.md` §6 porque condiciona el esquema y no puede resolverse durante la implementación.

## 7. Autorización en el servidor

Punto único de verificación antes de cada caso de uso: sesión válida, pertenencia al tenant y permiso sobre el recurso. Manejo de errores de autorización y por qué no se distingue entre "no existe" y "no tenés acceso" en las respuestas.

## 8. Protección de rutas

Rol del middleware, rutas públicas frente a privadas, y por qué la verificación real siempre ocurre del lado del servidor, en el caso de uso y no en la ruta.

## 9. Acceso público sin sesión

Reglas para la página de reserva online y para la gestión de un turno mediante enlace con token. Los enlaces son de vida corta, de un solo propósito y revocables; el modelo de amenazas completo de esta superficie está en `13-security.md` §7.

## 10. Sincronización y reconciliación

Webhooks de Clerk que mantienen consistentes usuarios y membresías, con verificación de firma e idempotencia, más un proceso de reconciliación periódica.

La reconciliación no es opcional: un webhook perdido deja a un usuario dado de baja en Clerk con acceso vigente en nuestra base, que es la que autoriza.

## 11. Acceso interno del equipo

Los roles internos no se modelan como roles dentro de un negocio. El acceso del equipo a datos de un cliente, su alcance y su auditoría se definen en `18-platform-admin.md`.
