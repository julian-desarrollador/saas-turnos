# 11 · Pagos

**Estado:** borrador · **Owner:** Producto + Arquitectura · **Última actualización:** 2026-07-27

## Propósito

Definir los dos flujos de dinero del sistema: la suscripción que cada negocio paga a la plataforma y, más adelante, los cobros que el negocio recibe de sus clientes. Son problemas distintos y no deben mezclarse.

Es además el dueño único del estado comercial del negocio: planes, límites y ciclo de vida de la suscripción se definen acá y el resto de los documentos los referencian.

## Índice

1. [Modelo de monetización](#1-modelo-de-monetización)
2. [Planes, límites y margen](#2-planes-límites-y-margen)
3. [Ciclo de vida de la suscripción](#3-ciclo-de-vida-de-la-suscripción)
4. [Integración con Mercado Pago](#4-integración-con-mercado-pago)
5. [Webhooks y conciliación](#5-webhooks-y-conciliación)
6. [Morosidad y suspensión](#6-morosidad-y-suspensión)
7. [Cambios de plan](#7-cambios-de-plan)
8. [Cobros del negocio a sus clientes](#8-cobros-del-negocio-a-sus-clientes)
9. [Señas y política de cancelación](#9-señas-y-política-de-cancelación)
10. [Facturación y comprobantes](#10-facturación-y-comprobantes)
11. [Seguridad de datos de pago](#11-seguridad-de-datos-de-pago)
12. [Pruebas y entorno sandbox](#12-pruebas-y-entorno-sandbox)

## 1. Modelo de monetización

Cómo gana dinero la plataforma: suscripción mensual por negocio, cargos por consumo de mensajería y período de prueba.

## 2. Planes, límites y margen

Definición de cada plan con sus límites de empleados, sucursales, turnos y notificaciones, y —lo más importante— su margen unitario.

El costo variable dominante es la mensajería. La proyección debe hacerse explícita antes de fijar precios, porque a escala domina la ecuación: con 2000 negocios y un volumen del orden de 600 turnos mensuales cada uno, dos mensajes por turno significan del orden de 2,4 millones de mensajes por mes. A ese volumen, el costo de mensajería por sí solo puede superar al ingreso de un plan mal dimensionado.

Esta sección debe contener: supuestos de volumen por tipo de negocio, costo unitario por canal, costo de identidad por organización activa, costo de infraestructura prorrateado y margen resultante por plan. Los precios no se publican hasta que esta tabla esté completa.

## 3. Ciclo de vida de la suscripción

Estados: en prueba, activa, con pago pendiente, suspendida y cancelada. Transiciones permitidas y efecto de cada estado sobre el acceso al producto.

Esta es la única definición del estado comercial de un negocio en toda la documentación. `06-multi-tenant.md` §10 describe cómo se aplica ese estado sobre el acceso, pero no lo redefine.

## 4. Integración con Mercado Pago

Suscripción recurrente con plan asociado, según el ADR-008. Credenciales por entorno y contrato interno que aísla al proveedor del resto del sistema.

## 5. Webhooks y conciliación

Recepción de eventos con verificación de firma e idempotencia, más un proceso de conciliación periódica contra el proveedor. La conciliación no es opcional: un evento perdido significa un negocio cobrado y bloqueado, o gratis e indefinido.

## 6. Morosidad y suspensión

Reintentos de cobro, avisos al negocio, plazo de gracia y degradación progresiva antes de suspender. Regla de fondo: nunca se corta el acceso a la agenda del día en curso sin aviso previo, porque eso deja al negocio sin poder trabajar.

## 7. Cambios de plan

Upgrade y downgrade, prorrateo, y qué ocurre cuando el negocio queda por encima de los límites del plan al bajar de nivel.

## 8. Cobros del negocio a sus clientes

Alcance futuro: pago del turno por parte del cliente final, modelo de conexión de cuentas y responsabilidad de la plataforma sobre ese dinero.

## 9. Señas y política de cancelación

Requerimiento de seña para reservar, monto y reglas de devolución ante cancelación o ausencia.

## 10. Facturación y comprobantes

Emisión de comprobantes por la suscripción, datos fiscales del negocio y límites explícitos de lo que la plataforma no resuelve.

## 11. Seguridad de datos de pago

La plataforma no almacena datos de tarjeta. Qué información sí se guarda, con qué protección y quién puede consultarla.

## 12. Pruebas y entorno sandbox

Cómo se prueba el flujo completo sin dinero real y qué escenarios deben validarse antes de habilitar cobros, incluidos los eventos de fallo y de reintento.
