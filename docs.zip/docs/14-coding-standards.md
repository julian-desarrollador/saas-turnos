# 14 · Estándares de código

**Estado:** borrador · **Owner:** Arquitectura · **Última actualización:** 2026-07-27

## Propósito

Fijar las convenciones de código y el proceso de revisión para que el proyecto se lea como escrito por una sola persona, independientemente de cuántas trabajen en él.

## Índice

1. [Principios generales](#1-principios-generales)
2. [TypeScript](#2-typescript)
3. [React y componentes](#3-react-y-componentes)
4. [Server Actions y validación](#4-server-actions-y-validación)
5. [Acceso a datos](#5-acceso-a-datos)
6. [Manejo de errores](#6-manejo-de-errores)
7. [Estilos con Tailwind y shadcn/ui](#7-estilos-con-tailwind-y-shadcnui)
8. [Nomenclatura](#8-nomenclatura)
9. [Textos e internacionalización](#9-textos-e-internacionalización)
10. [Testing](#10-testing)
11. [Comentarios y documentación](#11-comentarios-y-documentación)
12. [Git y pull requests](#12-git-y-pull-requests)
13. [Definición de terminado](#13-definición-de-terminado)

## 1. Principios generales

Claridad antes que ingenio, funciones pequeñas con una responsabilidad, evitar abstracciones prematuras y borrar código muerto.

## 2. TypeScript

Modo estricto, prohibición de `any` sin justificación, tipos derivados del esquema y validación en los límites del sistema.

## 3. React y componentes

Server Components por defecto, Client Components solo cuando hacen falta, composición sobre props booleanas y estado local acotado.

## 4. Server Actions y validación

Estructura estándar de una acción: validar entrada, autorizar, ejecutar caso de uso, revalidar caché y devolver resultado tipado.

## 5. Acceso a datos

Consultas encapsuladas por módulo, selección explícita de campos y filtro de tenant obligatorio. Toda operación con contexto de tenant se ejecuta dentro de una transacción, porque es ahí donde se fija la variable que habilita RLS (ADR-002 y ADR-006).

## 6. Manejo de errores

Errores de dominio tipados, distinción entre error esperado y fallo inesperado, mensajes al usuario sin filtrar detalles internos y registro con contexto.

## 7. Estilos con Tailwind y shadcn/ui

Uso de tokens del sistema de diseño, sin valores arbitrarios sin motivo, y cómo se aplican los colores del negocio sin romper accesibilidad.

## 8. Nomenclatura

Convenciones por tipo de artefacto e idioma: código en inglés, dominio y textos de interfaz en español.

## 9. Textos e internacionalización

Textos fuera de los componentes, formato de fechas, horas y moneda según la configuración del negocio.

## 10. Testing

Cómo se escribe y se nombra una prueba. Qué se testea de forma obligatoria y con qué criterio de bloqueo se define en `17-testing.md`.

## 11. Comentarios y documentación

Comentar el por qué y no el qué, y qué cambios obligan a actualizar la documentación en el mismo pull request.

## 12. Git y pull requests

Convención de commits, tamaño esperado de un pull request, plantilla de descripción y criterios de aprobación.

## 13. Definición de terminado

Checklist antes de considerar una tarea finalizada: tipos, tests, documentación, revisión y validación en preview.
