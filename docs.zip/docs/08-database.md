# 08 · Base de datos

**Estado:** borrador · **Owner:** Arquitectura · **Última actualización:** 2026-07-27

## Propósito

Definir el modelo de datos, las convenciones del esquema, la estrategia de migraciones y las decisiones de performance que sostienen la operación con miles de negocios.

## Índice

1. [Convenciones del esquema](#1-convenciones-del-esquema)
2. [Entidades principales](#2-entidades-principales)
3. [Relaciones y diagrama](#3-relaciones-y-diagrama)
4. [Columna de tenant e índices](#4-columna-de-tenant-e-índices)
5. [Manejo de fechas y zonas horarias](#5-manejo-de-fechas-y-zonas-horarias)
6. [Integridad y restricciones](#6-integridad-y-restricciones)
7. [Migraciones](#7-migraciones)
8. [Datos semilla](#8-datos-semilla)
9. [Borrado lógico](#9-borrado-lógico)
10. [Performance y volumen esperado](#10-performance-y-volumen-esperado)
11. [Archivado de datos históricos](#11-archivado-de-datos-históricos)
12. [Conexiones y pooling](#12-conexiones-y-pooling)
13. [Backups y restauración](#13-backups-y-restauración)

## 1. Convenciones del esquema

Nomenclatura de tablas y columnas, tipo de identificadores, campos de auditoría estándar y uso de enums.

## 2. Entidades principales

Listado y propósito de cada entidad: Tenant, Sucursal, Usuario, Membresía, Empleado, Servicio, Cliente, Turno, HorarioLaboral, Excepción de horario, Notificación, Suscripción y Log de auditoría.

## 3. Relaciones y diagrama

Diagrama entidad-relación y explicación de las relaciones no obvias (empleado ↔ servicio, turno ↔ recursos, cliente ↔ tenant). Un cliente atendido por dos negocios distintos es un registro por negocio: no hay identidad compartida de clientes finales entre tenants.

## 4. Columna de tenant e índices

Presencia obligatoria del identificador de tenant, y de sucursal, en toda tabla de negocio. Los índices compuestos empiezan siempre por la columna de tenant y se diseñan a partir de las consultas reales de la agenda, no de forma genérica.

## 5. Manejo de fechas y zonas horarias

Cada turno guarda la hora local acordada, la zona horaria IANA del negocio y un instante en UTC derivado para ordenar y consultar rangos. Ante un cambio de reglas horarias, la hora local prevalece y el instante se recalcula. Fundamento y consecuencias en el ADR-005.

## 6. Integridad y restricciones

Claves foráneas, restricciones únicas por tenant, y validaciones que deben vivir en la base y no solo en la aplicación. Incluye la restricción de no solapamiento de turnos, que es el control real contra la doble reserva.

## 7. Migraciones

Flujo de migraciones con Prisma, revisión previa y compatibilidad hacia atrás.

Regla de volumen: ninguna migración puede tomar un lock bloqueante sobre las tablas grandes. Los cambios sobre la tabla de turnos se hacen en pasos compatibles —agregar sin default costoso, rellenar por lotes, luego restringir— y los índices se crean sin bloquear escrituras.

## 8. Datos semilla

Datos base para desarrollo y para el alta de un negocio nuevo.

## 9. Borrado lógico

Qué entidades se archivan en lugar de borrarse y por qué. El registro de auditoría es competencia de `13-security.md` §10.

## 10. Performance y volumen esperado

Esta sección debe partir de números, no de adjetivos. Orden de magnitud a validar: 2000 negocios con del orden de 600 turnos mensuales generan cerca de 1,2 millones de filas por mes en la tabla de turnos, unos 43 millones a tres años. Es un volumen manejable para PostgreSQL, pero solo con índices alineados a las consultas y sin recorridos completos.

Contenido: patrones de consulta esperados, paginación, prevención de N+1, pre-agregación para reportes y detección de consultas lentas. Los objetivos de latencia están en `03-architecture.md` §12.

## 11. Archivado de datos históricos

Estrategia para que la tabla de turnos no crezca sin límite: criterio de antigüedad para archivar, dónde van los datos archivados y cómo se consultan cuando hacen falta. Decisión pendiente registrada en `15-decisions.md` §6.

## 12. Conexiones y pooling

PostgreSQL gestionado con pooler en modo transacción, conexión directa reservada para migraciones y mantenimiento (ADR-006). Consecuencia a respetar en el código: el contexto de tenant que habilita RLS se fija dentro de la transacción.

## 13. Backups y restauración

Frecuencia, retención, objetivo de recuperación y prueba periódica de restauración.

Incluye un caso que el backup completo no resuelve: restaurar los datos de un solo negocio a un punto anterior sin afectar al resto. Con miles de clientes, el borrado accidental por parte de un usuario es un evento frecuente, y la operación se expone en `18-platform-admin.md` §6.
