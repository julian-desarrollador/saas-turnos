# 06 · Multi-tenant

**Estado:** borrador · **Owner:** Arquitectura · **Última actualización:** 2026-07-27

## Propósito

Definir el modelo multi-tenant: qué es un tenant, cómo se identifica en cada request, cómo se garantiza el aislamiento de datos y cómo se personaliza la experiencia por negocio. Es el documento más crítico del proyecto: un error acá es una filtración de datos entre clientes.

## Índice

1. [Definición de tenant](#1-definición-de-tenant)
2. [Estrategia de aislamiento](#2-estrategia-de-aislamiento)
3. [Identificación del tenant](#3-identificación-del-tenant)
4. [Contexto de tenant en el servidor](#4-contexto-de-tenant-en-el-servidor)
5. [Aislamiento en la capa de datos](#5-aislamiento-en-la-capa-de-datos)
6. [Onboarding de un nuevo negocio](#6-onboarding-de-un-nuevo-negocio)
7. [Branding y configuración por tenant](#7-branding-y-configuración-por-tenant)
8. [Planes y límites por tenant](#8-planes-y-límites-por-tenant)
9. [Caché y claves por tenant](#9-caché-y-claves-por-tenant)
10. [Efecto del estado comercial sobre el acceso](#10-efecto-del-estado-comercial-sobre-el-acceso)
11. [Retención y eliminación de datos](#11-retención-y-eliminación-de-datos)
12. [Testing de aislamiento](#12-testing-de-aislamiento)

## 1. Definición de tenant

Un tenant es un negocio y es una entidad de nuestra base de datos, no del proveedor de identidad. Cada tenant tiene una Organization de Clerk asociada, pero la pertenencia de un usuario y su rol se resuelven contra nuestra base, según el ADR-001.

Un tenant contiene una o más sucursales, presentes en el esquema desde la primera migración aunque la funcionalidad se habilite más tarde (ADR-004).

## 2. Estrategia de aislamiento

Base de datos compartida con columna de tenant obligatoria en toda tabla de negocio, con RLS como segunda capa de defensa. Alternativas descartadas y sus motivos en el ADR-002.

## 3. Identificación del tenant

El negocio activo se resuelve por segmento de ruta usando su slug (ADR-003). Esta sección detalla el comportamiento cuando un usuario pertenece a varios negocios, cómo se cambia de uno a otro y cómo se mantienen las redirecciones si un slug cambia.

## 4. Contexto de tenant en el servidor

Mecanismo único y obligatorio para obtener el tenant activo en el servidor. El identificador que llega desde el cliente se usa para saber qué negocio se pide, nunca como prueba de que se tiene acceso a él: la pertenencia se verifica siempre contra la base.

## 5. Aislamiento en la capa de datos

Cómo se fuerza el filtro por tenant en toda consulta: acceso a datos encapsulado que lo inyecta, políticas de RLS en PostgreSQL, e índices compuestos que empiezan por la columna de tenant.

Detalle operativo relevante: RLS exige fijar la variable de tenant dentro de cada transacción, porque el pooler trabaja en modo transacción (ADR-006). Toda operación con contexto de tenant se ejecuta, por lo tanto, dentro de una transacción.

## 6. Onboarding de un nuevo negocio

Pasos al crear un negocio: alta del tenant y su sucursal inicial, creación de la organización en el proveedor de identidad, datos semilla (servicios y horarios por defecto) y estado inicial de prueba.

## 7. Branding y configuración por tenant

Logo, colores, zona horaria, moneda, idioma y preferencias operativas. Cómo se cargan y aplican sin romper el sistema de diseño, incluida la validación de contraste de los colores elegidos por el negocio.

## 8. Planes y límites por tenant

Dónde y cuándo se validan las cuotas del plan en tiempo de ejecución, y qué se le muestra al usuario al alcanzarlas. La definición de los planes y sus límites es competencia de `11-payments.md` §2 y no se duplica acá.

## 9. Caché y claves por tenant

Convención de claves de caché con el tenant incluido y reglas de invalidación para evitar contaminación cruzada. Aplica desde que exista caché compartida; con volumen bajo, la caché de la aplicación alcanza.

## 10. Efecto del estado comercial sobre el acceso

Qué puede hacer un negocio según el estado de su suscripción: acceso completo, degradado, solo lectura o bloqueado. Los estados posibles y sus transiciones se definen en `11-payments.md` §3; acá se describe únicamente cómo se aplican.

## 11. Retención y eliminación de datos

Qué ocurre con los datos de un negocio que se da de baja: plazo de conservación, exportación previa y eliminación definitiva. Las obligaciones legales que condicionan estos plazos están en `16-compliance.md` §7.

## 12. Testing de aislamiento

Requisito de cobertura obligatoria para toda operación expuesta. La estrategia y los escenarios concretos viven en `17-testing.md` §4.
