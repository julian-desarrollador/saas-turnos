# 04 · Stack tecnológico

**Estado:** borrador · **Owner:** Arquitectura · **Última actualización:** 2026-07-27

## Propósito

Registrar las tecnologías elegidas, por qué se eligieron, qué alternativas se descartaron y cómo se gestionan versiones y nuevas dependencias.

## Índice

1. [Criterios de elección](#1-criterios-de-elección)
2. [Frontend](#2-frontend)
3. [Backend](#3-backend)
4. [Base de datos y ORM](#4-base-de-datos-y-orm)
5. [Autenticación](#5-autenticación)
6. [Infraestructura y servicios](#6-infraestructura-y-servicios)
7. [Herramientas de desarrollo](#7-herramientas-de-desarrollo)
8. [Integraciones futuras](#8-integraciones-futuras)
9. [Alternativas descartadas](#9-alternativas-descartadas)
10. [Política de dependencias](#10-política-de-dependencias)

## 1. Criterios de elección

Qué optimizamos: velocidad de entrega, costo operativo bajo con pocos negocios, capacidad de escalar a miles y tamaño de equipo reducido.

## 2. Frontend

Next.js, React, TypeScript, Tailwind CSS y shadcn/ui. Rol de cada pieza y cómo se maneja el sistema de diseño con branding por tenant.

## 3. Backend

Next.js como backend mediante Server Actions y Route Handlers. Implicancias de correr en Vercel y límites a tener en cuenta.

## 4. Base de datos y ORM

PostgreSQL con Prisma, con pooler en modo transacción según el ADR-006. Uso previsto de transacciones e índices, y qué se resuelve en SQL en lugar del ORM.

## 5. Autenticación

Clerk como proveedor de identidad, con Organizations e Invitations. Los roles y las membresías son datos nuestros, no suyos (ADR-001). Su modelo de precios por organización activa se sigue como costo variable en `12-deployment.md` §12.

## 6. Infraestructura y servicios

Vercel (hosting), Cloudflare R2 (archivos), Trigger.dev (tareas recurrentes), Upstash Redis (rate limiting y, más adelante, caché).

Ninguno se contrata antes de necesitarlo: el criterio de incorporación progresiva está en `03-architecture.md` §11.

## 7. Herramientas de desarrollo

Gestor de paquetes, linter, formateo, hooks de git, testing y tipado estricto.

## 8. Integraciones futuras

Mercado Pago para pagos y WhatsApp mediante ChakraChat o 360dialog. Estado de evaluación de cada una.

## 9. Alternativas descartadas

Opciones consideradas y motivo del descarte, para no reabrir la discusión sin información nueva.

## 10. Política de dependencias

Reglas para agregar librerías: justificación, mantenimiento activo, tamaño, y quién aprueba.
