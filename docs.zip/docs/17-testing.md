# 17 · Estrategia de testing

**Estado:** borrador · **Owner:** Arquitectura · **Última actualización:** 2026-07-27

## Propósito

Definir qué se testea, cómo y con qué nivel de exigencia. Es el dueño único de la estrategia: `05-folder-structure.md`, `06-multi-tenant.md`, `09-booking-engine.md` y `14-coding-standards.md` describen aspectos parciales y referencian este documento.

Existe porque los dos riesgos más caros del producto —un turno duplicado y un dato visible entre negocios— solo se previenen con pruebas automatizadas.

## Índice

1. [Principios](#1-principios)
2. [Tipos de prueba y proporción](#2-tipos-de-prueba-y-proporción)
3. [Áreas de cobertura obligatoria](#3-áreas-de-cobertura-obligatoria)
4. [Pruebas de aislamiento entre tenants](#4-pruebas-de-aislamiento-entre-tenants)
5. [Pruebas del motor de reservas](#5-pruebas-del-motor-de-reservas)
6. [Pruebas de tiempo y zonas horarias](#6-pruebas-de-tiempo-y-zonas-horarias)
7. [Base de datos en pruebas](#7-base-de-datos-en-pruebas)
8. [Integraciones externas](#8-integraciones-externas)
9. [Pruebas de extremo a extremo](#9-pruebas-de-extremo-a-extremo)
10. [Datos de prueba](#10-datos-de-prueba)
11. [Ejecución en CI](#11-ejecución-en-ci)
12. [Criterios de bloqueo](#12-criterios-de-bloqueo)
13. [Qué no testeamos](#13-qué-no-testeamos)

## 1. Principios

Se testea el comportamiento, no la implementación. Se prioriza por costo del fallo, no por cobertura de líneas. Un test que nunca falla no aporta información.

## 2. Tipos de prueba y proporción

Distribución esperada entre pruebas unitarias, de integración contra base real y de extremo a extremo, con el criterio para elegir el nivel adecuado en cada caso.

## 3. Áreas de cobertura obligatoria

Áreas donde un pull request sin pruebas no se aprueba: aislamiento entre tenants, autorización por rol, motor de disponibilidad, transiciones de estado del turno, cálculo de recordatorios y procesamiento de webhooks.

## 4. Pruebas de aislamiento entre tenants

Batería que verifica que un usuario de un negocio no puede leer ni modificar datos de otro, ejecutada sobre cada operación expuesta. Incluye la comprobación de que el identificador de tenant enviado desde el cliente no altera el resultado.

## 5. Pruebas del motor de reservas

Escenarios obligatorios: solapamientos exactos y parciales, bordes de la jornada, servicios de distinta duración, excepciones y feriados, sobreturnos autorizados y creación concurrente del mismo horario.

## 6. Pruebas de tiempo y zonas horarias

Cómo se controla el reloj en las pruebas y qué casos se cubren: negocios en zonas distintas, cambios de reglas horarias y turnos agendados a futuro. Verifica lo decidido en el ADR-005.

## 7. Base de datos en pruebas

Uso de una PostgreSQL real en lugar de simulaciones, por ser el lugar donde viven restricciones y políticas de RLS. Estrategia de aislamiento entre pruebas y velocidad de la suite.

## 8. Integraciones externas

Cómo se prueban mensajería, pagos e identidad sin llamar a los proveedores: dobles de prueba que respetan el contrato interno, y verificación de firma e idempotencia de los webhooks entrantes.

## 9. Pruebas de extremo a extremo

Recorridos críticos cubiertos en un navegador real: reservar desde la página pública, crear un turno desde el panel, invitar a un empleado. Se mantienen pocos y estables.

## 10. Datos de prueba

Generación de negocios, empleados, servicios y turnos de prueba. Regla de que ningún dato real de clientes se usa en entornos de desarrollo.

## 11. Ejecución en CI

Qué corre en cada pull request y qué corre de forma programada por ser lento. Tiempo máximo aceptable de la suite de pull request.

## 12. Criterios de bloqueo

Condiciones que impiden mergear: fallo en cualquier prueba, ausencia de pruebas en un área obligatoria, prueba marcada como omitida sin justificación.

## 13. Qué no testeamos

Decisión explícita de no cubrir con pruebas automatizadas ciertos aspectos (estilos visuales, comportamiento de librerías de terceros) y por qué.
