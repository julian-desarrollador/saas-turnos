# 10 · Notificaciones

**Estado:** borrador · **Owner:** Arquitectura · **Última actualización:** 2026-07-27

## Propósito

Definir la capa de notificaciones del producto: qué eventos generan una comunicación, por qué canal salen, cómo se programan y cómo se controla su costo y su entrega.

Está organizado por capacidad y no por proveedor. WhatsApp es el canal principal para el cliente final, pero el email es un canal primario desde el primer día —invitaciones de empleados, recuperación de cuenta y avisos de cobro— y no un reemplazo de emergencia.

## Índice

1. [Eventos que generan notificaciones](#1-eventos-que-generan-notificaciones)
2. [Canales y criterio de uso](#2-canales-y-criterio-de-uso)
3. [Arquitectura de la capa de envío](#3-arquitectura-de-la-capa-de-envío)
4. [Programación por barrido periódico](#4-programación-por-barrido-periódico)
5. [Idempotencia y reintentos](#5-idempotencia-y-reintentos)
6. [WhatsApp · proveedor y plantillas](#6-whatsapp--proveedor-y-plantillas)
7. [WhatsApp · mensajes entrantes](#7-whatsapp--mensajes-entrantes)
8. [Email transaccional](#8-email-transaccional)
9. [Configuración por negocio](#9-configuración-por-negocio)
10. [Consentimiento y bajas](#10-consentimiento-y-bajas)
11. [Números de teléfono](#11-números-de-teléfono)
12. [Costo y cuotas](#12-costo-y-cuotas)
13. [Observabilidad y métricas](#13-observabilidad-y-métricas)

## 1. Eventos que generan notificaciones

Catálogo de eventos y su destinatario: confirmación de turno, recordatorio previo, reprogramación, cancelación y seguimiento posterior para el cliente final; invitación, recuperación de cuenta y avisos de cobro para el usuario del negocio.

## 2. Canales y criterio de uso

Qué canal se usa para cada evento y por qué. El email es obligatorio para todo lo relacionado con la cuenta; WhatsApp es el canal del cliente final. SMS queda como respaldo evaluado, no comprometido.

## 3. Arquitectura de la capa de envío

Contrato interno único de envío, con una implementación por canal y proveedor. Ningún módulo de dominio conoce al proveedor. Aplica el patrón de integraciones de `03-architecture.md` §10.

## 4. Programación por barrido periódico

Los envíos pendientes se registran como filas y una tarea recurrente despacha los que entran en la ventana actual. No se programa una tarea por turno: a volumen serían más de un millón de tareas mensuales, cada una con costo y con necesidad de cancelarse ante cada reprogramación. Decidido en el ADR-009.

## 5. Idempotencia y reintentos

Cómo se garantiza que un mismo evento no genere dos mensajes: clave de idempotencia por notificación, marcado transaccional del despacho y política de reintentos con espera creciente. Sigue el patrón general de `03-architecture.md` §7.

## 6. WhatsApp · proveedor y plantillas

Proveedor elegido según el ADR-007, gestión de plantillas aprobadas, variables permitidas, versionado, idioma y plazos de aprobación como dependencia de planificación.

## 7. WhatsApp · mensajes entrantes

Webhook de recepción con verificación de firma, y alcance acotado de lo que un cliente puede hacer respondiendo un mensaje. El número de teléfono no es una credencial: los números se reciclan entre personas, por lo que las acciones permitidas por esta vía se limitan según `13-security.md` §7.

## 8. Email transaccional

Proveedor, dominio remitente y su configuración de autenticación, separación entre correo de cuenta y correo de negocio, y manejo de rebotes.

## 9. Configuración por negocio

Qué puede configurar cada negocio: activar recordatorios, anticipación del envío, texto personalizado y firma, dentro de los límites que imponen las plantillas aprobadas.

## 10. Consentimiento y bajas

Registro del consentimiento del cliente final y mecanismo de baja. Define de forma explícita si la baja aplica al negocio que envió el mensaje o a toda la plataforma.

## 11. Números de teléfono

Normalización a formato internacional, validación en el momento de la carga y tratamiento de números inválidos o repetidos.

## 12. Costo y cuotas

Costo unitario por canal, cuota incluida en cada plan y comportamiento al superarla. Es la principal fuente de costo variable del producto: la proyección de volumen y margen vive en `11-payments.md` §2. Incluye alertas de consumo y frenos ante envíos masivos accidentales.

## 13. Observabilidad y métricas

Estados de entrega, tasa de fallos, latencia entre el momento previsto y el envío real, y trazabilidad de cada mensaje hasta el turno que lo originó. Alimenta el diagnóstico de soporte de `18-platform-admin.md` §7.
