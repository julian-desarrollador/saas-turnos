# 12 · Despliegue y operación

**Estado:** borrador · **Owner:** Arquitectura · **Última actualización:** 2026-07-27

## Propósito

Describir cómo se construye, despliega y opera el sistema: entornos, variables, migraciones, monitoreo y respuesta ante incidentes.

## Índice

1. [Entornos](#1-entornos)
2. [Variables de entorno y secretos](#2-variables-de-entorno-y-secretos)
3. [Ramas y flujo de trabajo](#3-ramas-y-flujo-de-trabajo)
4. [Pipeline de CI](#4-pipeline-de-ci)
5. [Despliegue en Vercel](#5-despliegue-en-vercel)
6. [Migraciones en producción](#6-migraciones-en-producción)
7. [Jobs y tareas programadas](#7-jobs-y-tareas-programadas)
8. [Dominios y DNS](#8-dominios-y-dns)
9. [Monitoreo y alertas](#9-monitoreo-y-alertas)
10. [Rollback y contingencia](#10-rollback-y-contingencia)
11. [Gestión de incidentes](#11-gestión-de-incidentes)
12. [Costos de infraestructura](#12-costos-de-infraestructura)

## 1. Entornos

Definición de local, preview y producción: qué servicios usa cada uno y qué datos contiene. Ningún entorno que no sea producción contiene datos reales de clientes.

## 2. Variables de entorno y secretos

Inventario de variables requeridas, dónde se almacenan, cómo se validan al arrancar la aplicación y cómo se rotan.

## 3. Ramas y flujo de trabajo

Estrategia de ramas, convención de commits, requisitos para mergear y quién puede desplegar.

## 4. Pipeline de CI

Verificaciones obligatorias antes de mergear: tipos, lint, validación del esquema y la suite de pruebas definida en `17-testing.md` §11.

## 5. Despliegue en Vercel

Configuración del proyecto, regiones, deploys automáticos y uso de preview para validación funcional. La elección de región se coordina con lo definido en `16-compliance.md` §6.

## 6. Migraciones en producción

Orden entre despliegue y migración, cambios compatibles hacia atrás y plan ante una migración fallida. Las reglas de volumen que evitan locks bloqueantes están en `08-database.md` §7.

## 7. Jobs y tareas programadas

Despliegue y versionado de tareas en Trigger.dev, monitoreo de ejecuciones y manejo de fallos. Las tareas son recurrentes y de barrido, no una por entidad (ADR-009).

## 8. Dominios y DNS

Dominio principal y certificados. No hay subdominio por negocio: el tenant se resuelve por ruta (ADR-003). Si en el futuro se ofrecen dominios propios para la página pública de reserva, se documenta acá.

## 9. Monitoreo y alertas

Qué se monitorea y con qué umbral: errores, latencia contra los objetivos de `03-architecture.md` §12, jobs fallidos, entregas de notificaciones, eventos de pago no conciliados y consumo de mensajería por encima de lo previsto. Canal de alerta y responsable.

## 10. Rollback y contingencia

Procedimiento para volver atrás un despliegue y modo de operación degradado ante la caída de cada proveedor externo, incluido el de identidad.

## 11. Gestión de incidentes

Clasificación por severidad, responsable de guardia, comunicación al cliente y análisis posterior.

## 12. Costos de infraestructura

Costo por servicio y proyección a 100, 500 y 2000 negocios, con revisión periódica.

Dos costos crecen linealmente con la cantidad de clientes y merecen seguimiento propio: el proveedor de identidad, que factura por organización activa, y la mensajería, que es el costo variable dominante. El impacto sobre el margen por plan se analiza en `11-payments.md` §2.
