# 13 · Seguridad

**Estado:** borrador · **Owner:** Arquitectura · **Última actualización:** 2026-07-27

## Propósito

Establecer los controles de seguridad del sistema. El producto maneja datos personales de clientes finales y, en verticales de salud, información sensible: el estándar debe ser alto desde el primer día.

Las obligaciones legales y de privacidad (base legal, retención, derechos de los titulares, transferencia internacional) viven en `16-compliance.md`; este documento cubre los controles técnicos.

## Índice

1. [Modelo de amenazas](#1-modelo-de-amenazas)
2. [Principios de seguridad](#2-principios-de-seguridad)
3. [Autenticación y sesiones](#3-autenticación-y-sesiones)
4. [Autorización y aislamiento](#4-autorización-y-aislamiento)
5. [Validación de entradas](#5-validación-de-entradas)
6. [Protección de endpoints](#6-protección-de-endpoints)
7. [Superficie pública de reserva](#7-superficie-pública-de-reserva)
8. [Rate limiting y abuso](#8-rate-limiting-y-abuso)
9. [Gestión de secretos](#9-gestión-de-secretos)
10. [Auditoría](#10-auditoría)
11. [Archivos subidos](#11-archivos-subidos)
12. [Exportación de datos](#12-exportación-de-datos)
13. [Dependencias y cadena de suministro](#13-dependencias-y-cadena-de-suministro)
14. [Respuesta ante incidentes](#14-respuesta-ante-incidentes)

## 1. Modelo de amenazas

Principales riesgos: acceso cruzado entre tenants, escalación de privilegios entre roles, abuso de la reserva pública, filtración por enlaces con token, exfiltración masiva por parte de un usuario legítimo y compromiso de credenciales del equipo.

## 2. Principios de seguridad

Mínimo privilegio, denegar por defecto, defensa en profundidad y validación siempre del lado del servidor.

## 3. Autenticación y sesiones

Delegación en Clerk, duración de sesión, cierre de sesión y segundo factor obligatorio para los roles con acceso a configuración y facturación.

## 4. Autorización y aislamiento

Verificación obligatoria de tenant y permiso en cada operación, con RLS como segunda capa (ADR-002), y controles automáticos que detectan consultas sin filtro de tenant antes de llegar a producción.

## 5. Validación de entradas

Validación con esquemas en el límite del servidor, sanitización y tipado estricto de todo dato de origen externo.

## 6. Protección de endpoints

Webhooks con verificación de firma obligatoria, endpoints internos protegidos, cabeceras de seguridad y política CORS restrictiva.

## 7. Superficie pública de reserva

Es el único punto del sistema accesible sin sesión y concentra el mayor riesgo. Tres amenazas específicas y sus controles:

**Enumeración de clientes.** Si el flujo identifica al cliente por teléfono o email y se comporta distinto cuando ya existe, cualquiera puede verificar si una persona es cliente de un negocio determinado. En un consultorio médico eso ya es un dato sensible. La respuesta debe ser indistinguible exista o no el cliente.

**Enlaces con token.** Los enlaces para gestionar un turno se reenvían, quedan en previsualizaciones de mensajería y sobreviven al turno. Deben ser de vida corta, de un solo propósito, revocables y sin datos personales en la URL.

**Acciones por respuesta de WhatsApp.** Confirmar o cancelar respondiendo un mensaje autentica por número de teléfono, y los números se reciclan entre personas. Define qué acciones se permiten por esa vía y cuáles exigen abrir el enlace.

Se suma la exposición de disponibilidad y nombres de profesionales, que permite a un tercero mapear la ocupación de un negocio: hay que decidir cuánto se publica.

## 8. Rate limiting y abuso

Dueño único de los límites de uso de todo el sistema. Límites por IP, por tenant y por acción usando Redis, con foco en reserva pública, invitaciones, exportaciones y envío de mensajes. Los otros documentos referencian esta sección en lugar de definir sus propios límites.

## 9. Gestión de secretos

Prohibición de secretos en el repositorio, separación por entorno, rotación y acceso restringido.

## 10. Auditoría

Dueño único del registro de auditoría. Eventos que se registran, información mínima de cada uno, retención y protección contra modificación. Incluye tanto acciones de usuarios del negocio como accesos internos del equipo.

## 11. Archivos subidos

Validación de tipo y tamaño, nombres no adivinables, aislamiento por tenant y acceso mediante URLs firmadas de corta duración.

## 12. Exportación de datos

La exportación es una funcionalidad legítima y a la vez el camino más directo para llevarse la base de clientes de un negocio. Requiere permiso explícito, límite de frecuencia, registro en auditoría y notificación al Owner.

## 13. Dependencias y cadena de suministro

Actualizaciones de seguridad, revisión de vulnerabilidades y control de scripts de instalación.

## 14. Respuesta ante incidentes

Detección, contención, notificación a los negocios afectados y análisis posterior documentado. Las obligaciones legales de notificación están en `16-compliance.md` §11.
