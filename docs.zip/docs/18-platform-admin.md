# 18 · Back-office de plataforma

**Estado:** borrador · **Owner:** Arquitectura + Operaciones · **Última actualización:** 2026-07-27

## Propósito

Definir las herramientas internas con las que el equipo opera la plataforma y da soporte a los negocios. Con miles de clientes esto deja de ser una pantalla auxiliar y pasa a ser una aplicación de uso diario, con el nivel de acceso más alto del sistema y, por lo tanto, el mayor riesgo.

## Índice

1. [Alcance y usuarios](#1-alcance-y-usuarios)
2. [Separación del panel de negocio](#2-separación-del-panel-de-negocio)
3. [Gestión de negocios](#3-gestión-de-negocios)
4. [Acceso de soporte e impersonación](#4-acceso-de-soporte-e-impersonación)
5. [Auditoría del acceso interno](#5-auditoría-del-acceso-interno)
6. [Operaciones sobre un tenant](#6-operaciones-sobre-un-tenant)
7. [Diagnóstico de notificaciones](#7-diagnóstico-de-notificaciones)
8. [Estado de suscripciones](#8-estado-de-suscripciones)
9. [Métricas de plataforma](#9-métricas-de-plataforma)
10. [Roles internos](#10-roles-internos)
11. [Operaciones destructivas](#11-operaciones-destructivas)

## 1. Alcance y usuarios

Quiénes usan el back-office (soporte, operaciones, ingeniería) y qué tareas resuelve cada perfil.

## 2. Separación del panel de negocio

Por qué el back-office vive en una superficie separada con su propio control de acceso, y por qué un rol interno nunca se modela como un rol dentro de un negocio.

## 3. Gestión de negocios

Alta, búsqueda, consulta de configuración y estado de cada negocio, sin exponer datos de clientes finales cuando no es necesario para la tarea.

## 4. Acceso de soporte e impersonación

Capacidad más sensible del sistema. Define si el equipo puede ver el panel como un negocio, bajo qué condición se habilita, si requiere autorización previa del cliente, cuánto dura la sesión y qué acciones quedan prohibidas durante la impersonación.

## 5. Auditoría del acceso interno

Todo acceso interno a datos de un negocio queda registrado con quién, cuándo, qué vio y por qué. El registro es inmutable para quien lo genera y revisable de forma periódica.

## 6. Operaciones sobre un tenant

Acciones operativas frecuentes: suspender, reactivar, exportar datos, eliminar datos y restaurar la información de un solo negocio a un punto anterior sin afectar al resto.

## 7. Diagnóstico de notificaciones

Visibilidad del estado de los mensajes de un negocio para responder la consulta más común de soporte: por qué un recordatorio no llegó.

## 8. Estado de suscripciones

Consulta del estado de cobro de cada negocio y acciones manuales excepcionales, delimitando cuáles se permiten y quién las autoriza.

## 9. Métricas de plataforma

Indicadores agregados de operación: negocios activos, volumen de turnos, consumo de mensajería y errores por negocio.

## 10. Roles internos

Perfiles del equipo y alcance de cada uno, aplicando mínimo privilegio: soporte no necesita el mismo acceso que ingeniería.

## 11. Operaciones destructivas

Acciones irreversibles que requieren doble confirmación o aprobación de una segunda persona, y su registro obligatorio.
