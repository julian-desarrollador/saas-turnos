# 16 · Cumplimiento y protección de datos

**Estado:** borrador · **Owner:** Arquitectura + Legal · **Última actualización:** 2026-07-27

## Propósito

Definir qué datos personales trata la plataforma, bajo qué marco legal y con qué obligaciones. Existe porque varios verticales objetivo son de salud (odontología, consultorios, dermocosmiatría) y eso convierte parte de los datos en categoría sensible, con deberes reforzados de custodia.

Excluir la historia clínica del alcance de producto no elimina la obligación: si el dato termina en la base, el deber de custodia es nuestro. Este documento define cómo se evita o se asume esa situación de forma consciente.

## Índice

1. [Marco legal aplicable](#1-marco-legal-aplicable)
2. [Roles frente a la ley](#2-roles-frente-a-la-ley)
3. [Clasificación de datos](#3-clasificación-de-datos)
4. [Decisión sobre datos clínicos](#4-decisión-sobre-datos-clínicos)
5. [Base legal y consentimiento](#5-base-legal-y-consentimiento)
6. [Transferencia internacional de datos](#6-transferencia-internacional-de-datos)
7. [Minimización y retención](#7-minimización-y-retención)
8. [Derechos de los titulares](#8-derechos-de-los-titulares)
9. [Encargados de tratamiento](#9-encargados-de-tratamiento)
10. [Documentos contractuales](#10-documentos-contractuales)
11. [Notificación de incidentes](#11-notificación-de-incidentes)
12. [Revisión periódica](#12-revisión-periódica)

## 1. Marco legal aplicable

Normativa que rige el tratamiento: Ley 25.326 de Protección de Datos Personales y su tratamiento reforzado de datos sensibles, normativa de derechos del paciente cuando aplique, y regulación de mensajería comercial. Alcance por país si se expande fuera de Argentina.

## 2. Roles frente a la ley

Distinción entre el negocio, que es responsable de los datos de sus clientes, y la plataforma, que actúa como encargada del tratamiento. Esta separación determina quién responde ante un reclamo y qué debe decir el contrato.

## 3. Clasificación de datos

Inventario de los datos que trata el sistema, clasificados por nivel: identificación del cliente, datos de contacto, historial de turnos, notas libres y, eventualmente, datos de salud. Para cada nivel, controles exigidos.

## 4. Decisión sobre datos clínicos

Punto central del documento. Define si el producto acepta información clínica en campos de notas o la evita por diseño, y qué controles acompañan la opción elegida: advertencia al usuario, cifrado adicional, restricción de acceso por rol, exclusión de logs y de exportaciones. Decisión abierta registrada en `15-decisions.md` §6.

## 5. Base legal y consentimiento

Fundamento del tratamiento para cada finalidad: prestación del servicio, envío de recordatorios y comunicaciones comerciales. Cómo se registra el consentimiento y cómo se prueba.

## 6. Transferencia internacional de datos

Ubicación real de los datos en cada proveedor (hosting, base de datos, archivos, mensajería) y requisitos aplicables cuando salen del país. Criterio de selección de región.

## 7. Minimización y retención

Qué datos no se piden porque no son necesarios, y plazos de conservación por tipo de dato, incluidos los de negocios dados de baja. Relación con el ciclo de vida del tenant.

## 8. Derechos de los titulares

Procedimiento ante pedidos de acceso, rectificación, supresión y portabilidad, tanto de un negocio como de un cliente final. Plazos de respuesta y responsable.

## 9. Encargados de tratamiento

Listado de subencargados (proveedores que acceden a datos personales), qué dato ve cada uno y con qué garantía contractual.

## 10. Documentos contractuales

Términos de servicio, política de privacidad y acuerdo de tratamiento de datos con los negocios. Estado de cada uno y quién los redacta.

## 11. Notificación de incidentes

Obligaciones de aviso ante una brecha: a quién, en qué plazo y con qué contenido. Se coordina con el procedimiento técnico de `13-security.md` §14.

## 12. Revisión periódica

Frecuencia de revisión de este documento y disparadores que la fuerzan: nuevo vertical, nuevo proveedor, nueva jurisdicción.
