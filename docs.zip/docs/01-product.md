# 01 · Producto

**Estado:** borrador · **Owner:** Producto · **Última actualización:** 2026-07-27

## Propósito

Definir qué es el producto, para quién es, qué problema resuelve y cuáles son sus límites. Es el documento que resuelve discusiones de alcance: si algo no está acá, no se construye.

## Índice

1. [Visión](#1-visión)
2. [Problema](#2-problema)
3. [Segmentos de negocio](#3-segmentos-de-negocio)
4. [Personas y roles](#4-personas-y-roles)
5. [Módulos funcionales](#5-módulos-funcionales)
6. [Casos de uso principales](#6-casos-de-uso-principales)
7. [Fuera de alcance](#7-fuera-de-alcance)
8. [Métricas de éxito](#8-métricas-de-éxito)
9. [Glosario](#9-glosario)

## 1. Visión

Enunciado de una frase sobre qué logra el producto y en qué se diferencia de agendas genéricas y planillas.

## 2. Problema

Dolores concretos del negocio de servicios: turnos perdidos, ausencias sin aviso, gestión por WhatsApp manual, falta de historial de clientes, sin visibilidad de ocupación.

## 3. Segmentos de negocio

Verticales objetivo (peluquería, estética, dermocosmiatría, odontología, consultorios, gimnasios) y qué necesita cada uno de distinto: duración de servicios, recursos, box/sillón, sesiones múltiples.

## 4. Personas y roles

Perfiles de usuario y qué espera cada uno del producto: dueño del negocio, administrador, profesional/empleado, recepción, cliente final y operador de la plataforma.

## 5. Módulos funcionales

Descripción breve de cada módulo: agenda, clientes, empleados, servicios, horarios, configuración y marca (logo, colores), recordatorios, permisos, panel administrativo del negocio y back-office de la plataforma.

## 6. Casos de uso principales

Flujos que el producto debe resolver de punta a punta: crear un turno desde recepción, reservar online desde el link público, reprogramar, cancelar, registrar ausencia, invitar a un empleado, configurar horarios y feriados.

## 7. Fuera de alcance

Lo que explícitamente no hacemos en el corto plazo: facturación electrónica, historia clínica regulada, stock e inventario, nómina, contabilidad, app móvil nativa.

Advertencia sobre la historia clínica: excluirla del alcance no impide que un profesional escriba información de salud en un campo de notas, y si ese dato queda en la base, el deber de custodia es nuestro. El tratamiento de ese riesgo se decide en `16-compliance.md` §4.

## 8. Métricas de éxito

Indicadores de producto y negocio: negocios activos, turnos gestionados por semana, tasa de ausencias, adopción de recordatorios, retención mensual, churn. Para cada uno, cómo se mide y de dónde sale el dato; una métrica sin fuente definida no se publica.

## 9. Glosario

Vocabulario compartido del dominio para usar de forma consistente en código, base de datos y UI: tenant, negocio, sucursal, servicio, profesional, turno, slot, disponibilidad, excepción.
