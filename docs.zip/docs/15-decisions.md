# 15 · Registro de decisiones (ADR)

**Estado:** activo · **Owner:** Arquitectura · **Última actualización:** 2026-07-27

## Propósito

Conservar el historial de decisiones de arquitectura con su contexto y consecuencias. Sirve para entender por qué el sistema es como es y para no reabrir discusiones ya cerradas sin información nueva.

## Índice

1. [Cómo usar este registro](#1-cómo-usar-este-registro)
2. [Formato de una decisión](#2-formato-de-una-decisión)
3. [Estados posibles](#3-estados-posibles)
4. [Índice de decisiones](#4-índice-de-decisiones)
5. [Decisiones](#5-decisiones)
6. [Decisiones pendientes](#6-decisiones-pendientes)

## 1. Cómo usar este registro

Toda decisión que sea costosa de revertir se registra acá antes de implementarse. Las decisiones no se editan una vez aceptadas: se reemplazan por una nueva que las declara obsoletas.

Ninguna decisión en estado *propuesta* habilita implementación. Cerrar las decisiones de esta página es el primer entregable de la Fase 0 del roadmap.

## 2. Formato de una decisión

Cada entrada incluye: número, título, fecha, estado, contexto, decisión, alternativas consideradas y consecuencias (positivas y negativas).

## 3. Estados posibles

Propuesta, aceptada, rechazada, obsoleta (reemplazada por otra decisión).

## 4. Índice de decisiones

| # | Decisión | Fecha | Estado |
| --- | --- | --- | --- |
| [001](#adr-001--la-base-de-datos-propia-es-autoritativa-sobre-tenants-y-permisos) | La base de datos propia es autoritativa sobre tenants y permisos | 2026-07-27 | Propuesta |
| [002](#adr-002--aislamiento-multi-tenant-por-columna-con-rls-y-repositorio-encapsulado) | Aislamiento multi-tenant por columna, con RLS y repositorio encapsulado | 2026-07-27 | Propuesta |
| [003](#adr-003--el-tenant-se-identifica-por-segmento-de-ruta) | El tenant se identifica por segmento de ruta | 2026-07-27 | Propuesta |
| [004](#adr-004--las-sucursales-son-una-entidad-hija-del-tenant-desde-el-esquema-inicial) | Las sucursales son una entidad hija del tenant desde el esquema inicial | 2026-07-27 | Propuesta |
| [005](#adr-005--los-turnos-se-almacenan-como-hora-local-más-zona-horaria) | Los turnos se almacenan como hora local más zona horaria | 2026-07-27 | Propuesta |
| [006](#adr-006--postgresql-gestionado-con-pooler-en-modo-transacción) | PostgreSQL gestionado con pooler en modo transacción | 2026-07-27 | Propuesta |
| [007](#adr-007--proveedor-de-whatsapp-detrás-de-una-capa-de-abstracción) | Proveedor de WhatsApp detrás de una capa de abstracción | 2026-07-27 | Propuesta |
| [008](#adr-008--cobro-recurrente-con-suscripciones-de-mercado-pago) | Cobro recurrente con suscripciones de Mercado Pago | 2026-07-27 | Propuesta |
| [009](#adr-009--los-recordatorios-se-despachan-por-barrido-periódico) | Los recordatorios se despachan por barrido periódico | 2026-07-27 | Propuesta |

## 5. Decisiones

### ADR-001 · La base de datos propia es autoritativa sobre tenants y permisos

**Fecha:** 2026-07-27 · **Estado:** propuesta

**Contexto.** Clerk Organizations puede representar el negocio y almacenar membresías y roles. Si esa información es autoritativa, cada decisión de autorización depende de un proveedor externo: una caída deja a todos los negocios sin operar, los cambios de rol propagan recién al refrescar el token, y el costo crece por organización activa.

**Decisión.** Clerk es el proveedor de identidad y responde una única pregunta: quién es el usuario. La pertenencia a un negocio, el rol y los permisos viven en nuestra base de datos y son la única fuente consultada al autorizar.

**Alternativas consideradas.** Clerk como fuente de verdad de membresías y roles, leyendo los claims del token en cada request. Se descarta por acoplamiento y por la ventana de permisos obsoletos.

**Consecuencias.** Autorización verificable localmente y testeable sin red. A cambio, hay que mantener la sincronización con Clerk mediante webhooks y un proceso de reconciliación periódica, porque un webhook perdido deja permisos divergentes.

### ADR-002 · Aislamiento multi-tenant por columna, con RLS y repositorio encapsulado

**Fecha:** 2026-07-27 · **Estado:** propuesta

**Contexto.** Con miles de negocios en una base compartida, una consulta sin filtro de tenant es una filtración de datos entre clientes. Confiar solo en que el desarrollador recuerde filtrar no es un control.

**Decisión.** Base de datos compartida con columna de tenant obligatoria en toda tabla de negocio, y dos capas de defensa: acceso a datos encapsulado que inyecta el filtro, y Row Level Security en PostgreSQL como red de contención.

**Alternativas consideradas.** Schema por tenant y base por tenant: se descartan por costo operativo de migrar miles de schemas y por el límite práctico de conexiones. Solo repositorio encapsulado sin RLS: se descarta porque un acceso directo accidental queda sin red.

**Consecuencias.** Un error de filtrado no alcanza para filtrar datos. El costo es operativo: RLS requiere fijar la variable de sesión del tenant dentro de cada transacción, lo que condiciona el modo de pooling (ver ADR-006) y obliga a que toda escritura pase por la capa que la establece.

### ADR-003 · El tenant se identifica por segmento de ruta

**Fecha:** 2026-07-27 · **Estado:** propuesta

**Contexto.** El negocio activo puede resolverse por subdominio o por segmento de ruta. La elección afecta DNS, certificados, cookies de sesión y el flujo de un usuario que pertenece a varios negocios.

**Decisión.** El negocio activo se resuelve por segmento de ruta, usando el slug del negocio. El identificador que llega en la URL se valida siempre contra la membresía del usuario; nunca se toma como autorización en sí mismo.

**Alternativas consideradas.** Subdominio por negocio: mejor percepción de marca, pero suma emisión de certificados, complejidad de cookies entre subdominios y fricción para cambiar de negocio. Queda disponible como capa opcional futura para dominios propios en la página pública de reserva.

**Consecuencias.** Una sola configuración de dominio y sesión. A cambio, la URL del panel es menos personalizada, y todo enlace compartido incluye el slug, por lo que renombrarlo debe mantener redirecciones.

### ADR-004 · Las sucursales son una entidad hija del tenant desde el esquema inicial

**Fecha:** 2026-07-27 · **Estado:** propuesta

**Contexto.** El roadmap ubica el soporte de sucursales en una fase avanzada, pero la decisión afecta si las tablas de agenda, empleados y servicios llevan o no una referencia a sucursal. Agregarla después implica migrar tablas de decenas de millones de filas.

**Decisión.** Un negocio es un tenant y puede tener una o más sucursales. La referencia a sucursal se incluye en el esquema desde la primera migración; los negocios de una sola sede operan con una sucursal implícita y no ven el concepto en la interfaz hasta que se habilite.

**Alternativas consideradas.** Sucursal como tenant independiente: descartada porque obliga a duplicar clientes, servicios y facturación, y rompe la visión consolidada del negocio.

**Consecuencias.** El costo de la funcionalidad se paga una sola vez y temprano, en forma de una columna adicional y un filtro más. Evita una migración riesgosa años después.

### ADR-005 · Los turnos se almacenan como hora local más zona horaria

**Fecha:** 2026-07-27 · **Estado:** propuesta

**Contexto.** Guardar los turnos exclusivamente en UTC es correcto para eventos pasados, pero para turnos futuros introduce un riesgo real: si el país modifica sus reglas horarias, todos los turnos ya agendados se corren respecto de la hora que el negocio y el cliente acordaron. Argentina cambió su política de horario de verano varias veces.

**Decisión.** Cada turno guarda la hora local acordada junto con la zona horaria IANA del negocio, y además un instante en UTC derivado que se usa para ordenar, consultar rangos y programar notificaciones. Ante un cambio de reglas horarias, la hora local es la verdad y el instante UTC se recalcula.

**Alternativas consideradas.** Solo UTC, más simple de consultar pero frágil ante cambios de reglas. Solo hora local, imposible de ordenar entre negocios de distintas zonas.

**Consecuencias.** Consultas correctas y turnos estables ante cambios normativos. El costo es un campo derivado que debe mantenerse consistente y un proceso de recálculo ante actualizaciones de la base de zonas horarias.

### ADR-006 · PostgreSQL gestionado con pooler en modo transacción

**Fecha:** 2026-07-27 · **Estado:** propuesta

**Contexto.** El entorno serverless abre y cierra procesos con frecuencia, y sin un pooler externo se agotan las conexiones de PostgreSQL. A la vez, el modo transacción es incompatible con variables de sesión fijadas fuera de una transacción, lo que interactúa directamente con el RLS de ADR-002.

**Decisión.** PostgreSQL gestionado por un proveedor con pooler integrado en modo transacción. La variable de tenant que habilita RLS se fija dentro de cada transacción, no a nivel de conexión. Las migraciones y tareas de mantenimiento usan la conexión directa, sin pooler.

**Alternativas consideradas.** Conexión directa sin pooler, descartada por agotamiento de conexiones. Pooler en modo sesión, que permitiría variables de sesión persistentes pero reduce el reuso de conexiones.

**Consecuencias.** Escala en conexiones y compatibilidad con RLS. El costo es que toda operación con contexto de tenant debe ejecutarse dentro de una transacción, lo que hay que reflejar en la capa de acceso a datos.

### ADR-007 · Proveedor de WhatsApp detrás de una capa de abstracción

**Fecha:** 2026-07-27 · **Estado:** propuesta

**Contexto.** La mensajería es la funcionalidad de mayor costo variable y la más expuesta a decisiones ajenas: políticas de Meta, aprobación de plantillas y precios del proveedor. Comprometerse con un proveedor a nivel de código es un riesgo de negocio.

**Decisión.** Se define un contrato interno de envío de mensajes y el proveedor queda detrás de una implementación reemplazable. La preferencia inicial es un proveedor oficial de soluciones de Meta, con 360dialog como candidato principal por esa condición y ChakraChat como alternativa a evaluar comercialmente.

**Alternativas consideradas.** Integración directa contra la API de Meta, que aporta control pero suma trabajo de verificación y facturación propia.

**Consecuencias.** El proveedor puede cambiarse sin reescribir el módulo de notificaciones. La comparación comercial sigue abierta y debe cerrarse antes de la fase de recordatorios; esta decisión no la resuelve, solo garantiza que sea reversible.

### ADR-008 · Cobro recurrente con suscripciones de Mercado Pago

**Fecha:** 2026-07-27 · **Estado:** propuesta

**Contexto.** El mercado objetivo es Argentina y los negocios esperan pagar con medios locales. Hay que elegir entre cobrar cada período de forma manual o usar el mecanismo de suscripciones con débito automático.

**Decisión.** Suscripción recurrente con plan asociado en Mercado Pago, con el estado de la suscripción reflejado en nuestra base a partir de los eventos recibidos y verificado periódicamente por conciliación.

**Alternativas consideradas.** Cobro manual por período: menor integración pero mora alta y trabajo administrativo creciente con cada cliente nuevo.

**Consecuencias.** Ingreso recurrente previsible y menos gestión manual. El costo es depender de la disponibilidad de los eventos del proveedor, lo que obliga a un proceso de conciliación que no puede postergarse.

### ADR-009 · Los recordatorios se despachan por barrido periódico

**Fecha:** 2026-07-27 · **Estado:** propuesta

**Contexto.** Programar una tarea por cada turno parece natural, pero con miles de negocios significa más de un millón de tareas programadas por mes, cada una con costo y con la obligación de cancelarse o reprogramarse cada vez que el turno cambia de horario.

**Decisión.** Los envíos pendientes se registran como filas en una tabla de notificaciones y una tarea recurrente de frecuencia corta despacha las que corresponden a la ventana actual, marcándolas de forma idempotente.

**Alternativas consideradas.** Una tarea programada por turno, descartada por costo y por la complejidad de mantenerla sincronizada con reprogramaciones y cancelaciones.

**Consecuencias.** El volumen de ejecuciones deja de crecer con la cantidad de turnos y las reprogramaciones no requieren lógica de cancelación. El costo es una latencia de envío acotada por la frecuencia del barrido, que debe ser aceptable para un recordatorio.

## 6. Decisiones pendientes

Temas abiertos que todavía no tienen decisión registrada:

- Comparación comercial definitiva entre proveedores de WhatsApp (cierra ADR-007).
- Alcance de datos clínicos: si se aceptan notas con información de salud o se bloquean por diseño. Ver `16-compliance.md`.
- Modelo de permisos: roles fijos o permisos granulares por recurso. Ver `07-authentication.md` §6.
- Estrategia de archivado o particionado de turnos históricos. Ver `08-database.md` §11.
