# 09 · Motor de reservas

**Estado:** borrador · **Owner:** Arquitectura · **Última actualización:** 2026-07-27

## Propósito

Especificar el corazón funcional del producto: cómo se calcula la disponibilidad, cómo se crea un turno sin generar solapamientos y cuáles son las reglas de negocio del ciclo de vida de un turno.

## Índice

1. [Conceptos y vocabulario](#1-conceptos-y-vocabulario)
2. [Definición de disponibilidad](#2-definición-de-disponibilidad)
3. [Cálculo de slots](#3-cálculo-de-slots)
4. [Reglas de reserva](#4-reglas-de-reserva)
5. [Estados del turno](#5-estados-del-turno)
6. [Concurrencia y doble reserva](#6-concurrencia-y-doble-reserva)
7. [Reprogramación y cancelación](#7-reprogramación-y-cancelación)
8. [Ausencias y sobreturnos](#8-ausencias-y-sobreturnos)
9. [Casos especiales por vertical](#9-casos-especiales-por-vertical)
10. [Reserva pública](#10-reserva-pública)
11. [Performance de la agenda](#11-performance-de-la-agenda)
12. [Casos de prueba obligatorios](#12-casos-de-prueba-obligatorios)

## 1. Conceptos y vocabulario

Definición precisa de slot, disponibilidad, capacidad, recurso, duración, tiempo de preparación y tiempo de limpieza.

## 2. Definición de disponibilidad

Fuentes que determinan si un horario está libre: horario de la sucursal, horario del empleado, excepciones, feriados, bloqueos y turnos existentes. Todo cálculo se hace en la hora local del negocio según el ADR-005.

## 3. Cálculo de slots

Algoritmo de generación de horarios ofrecidos: granularidad, alineación, duración del servicio y ventana de anticipación.

## 4. Reglas de reserva

Restricciones configurables: anticipación mínima y máxima, límite de turnos por cliente, servicios habilitados por empleado, requisitos de seña.

## 5. Estados del turno

Máquina de estados: pendiente, confirmado, atendido, cancelado, ausente. Transiciones permitidas y quién puede ejecutarlas.

## 6. Concurrencia y doble reserva

Garantía de no solapamiento bajo pedidos simultáneos. El control real es la restricción de exclusión en la base de datos (`08-database.md` §6); la validación previa en la aplicación mejora el mensaje de error, pero no previene nada.

## 7. Reprogramación y cancelación

Reglas de plazo, políticas del negocio, efectos sobre notificaciones ya programadas y trazabilidad del cambio.

## 8. Ausencias y sobreturnos

Registro de ausencia del cliente y creación de turnos fuera de la disponibilidad estándar con permiso explícito.

## 9. Casos especiales por vertical

Sesiones múltiples, turnos con más de un profesional, servicios con recursos limitados y clases con capacidad grupal.

Estos casos son la principal fuente de sobrediseño del modelo de datos. El MVP cierra con un modelo simple —un turno, un profesional, un servicio— y cada extensión requiere una decisión registrada antes de tocar el esquema.

## 10. Reserva pública

Flujo del cliente final sin sesión: selección de servicio y profesional, identificación y confirmación. Los controles de abuso, enumeración de clientes y enlaces con token se definen en `13-security.md` §7, que es el dueño de esta superficie desde el punto de vista de riesgo.

## 11. Performance de la agenda

Estrategia para responder rápido en vistas de día, semana y mes, y para calcular disponibilidad sin recorrer datos innecesarios. Los objetivos de latencia que hay que cumplir están en `03-architecture.md` §12.

## 12. Casos de prueba obligatorios

Este módulo no se modifica sin pruebas. Los escenarios exigidos —solapamientos, bordes de jornada, zonas horarias, cancelaciones y concurrencia— están detallados en `17-testing.md` §5.
